/* global QUnit */

sap.ui.require(["ui5qrcoderendering/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
