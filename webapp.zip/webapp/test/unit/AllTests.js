sap.ui.define([
	"ui5_qrcode_rendering/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
