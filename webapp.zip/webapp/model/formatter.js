sap.ui.define([

], function () {
    "use strict";

    return {




        setSrc: function () {
            debugger
            return 'https://chart.apis.google.com/chart?cht=qr&chs=250x250&chl=https://qr.kinder.com/VV100'
        }

    };
});